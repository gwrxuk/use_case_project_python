# use_case_project_python
1. CSV file format is: Name, Age, Area
2. Read CSV and insert data to Sqlite is: ./usecase test.csv
